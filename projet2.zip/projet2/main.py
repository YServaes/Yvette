# This is a sample Python script.

# Press Maj+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.


def test_pos2d_eq():
    from pos2d import Pos2D
    from grid import Grid
    from renderer import GridRenderer
    from box import Box
    point1 = Pos2D(0, 0)
    point2 = Pos2D(3, 4)
#    Grid(3,4)
#    a=1
    #Grid(3,4).isolate_box(Box(Pos2D(1,1),Pos2D(2,2)))
    #GridRenderer(Grid(3,4)).show()
    #params = {'width': 40, 'height': 20, 'rooms': 5, 'bonuses': 2, 'seed': None, 'view_radius': 6, 'torch_delay': 7,
    # 'bonus_radius': 3, 'minwidth': 4, 'maxwidth': 8, 'minheight': 4, 'maxheight': 8, 'openings': 2, 'hard': False,
    # 'ghosts': 0, 'ghosts_delay': 2, 'ghosts_walls': False, 'params': {...}}

    params = {'width': 40}
    import argparse
    from generation import DungeonGenerator
    from grid import Grid
    dungeon = DungeonGenerator(argparse.Namespace(40)).generate()


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    test_pos2d_eq()
# See PyCharm help at https://www.jetbrains.com/help/pycharm/
