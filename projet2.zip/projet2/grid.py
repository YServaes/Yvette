#
#from pos2d import Pos2D
from box import *

# Node retourne les actions possibles à partir d'une position
# Node permet également de modifier ces actions lors de la construction du labyrinthe
class Node:

    def getActions(myBox: Box, pos: Pos2D):
        x = pos.x
        y = pos.y
        actions = myBox.getElement(x, y)
        return actions

    def setActions(myBox: Box, pos: Pos2D, sens: str, action: bool):
        x = pos.x
        y = pos.y
        actions = myBox.getElement(x, y)
        if (sens == 'up'):
            actions[0] = action
        if (sens == 'left'):
            actions[1] = action
        if (sens == 'down'):
            actions[2] = action
        if (sens == 'right'):
            actions[3] = action

class Grid:

    def change_action(self, pos1: Pos2D, pos2: Pos2D, action: bool):
        if (pos1.x == pos2.x):
            # même ligne
            if (pos2.y == (pos1.y + 1)):
                Node.setActions(self.box, pos1, 'down', action)
                Node.setActions(self.box, Pos2D(pos2.y,pos2.x), 'up', action)
            if (pos2.y == (pos1.y - 1)):
                Node.setActions(self.box, pos2, 'down', action)
                Node.setActions(self.box, Pos2D(pos1.y,pos1.x), 'up', action)
        if (pos1.y == pos2.y):
            # même colonne
            if (pos2.x == (pos1.x + 1)):
                Node.setActions(self.box, pos1, 'right', action)
                Node.setActions(self.box, Pos2D(pos2.y,pos2.x), 'left', action)
            if (pos2.x == (pos1.x - 1)):
                Node.setActions(self.box, pos2, 'right', action)
                Node.setActions(self.box, Pos2D(pos1.y,pos1.x), 'left', action)

    def __init__(self, width: int, height: int):
        # construit une grille par défaut avec les murs de contours
        ul = Pos2D(0, 0)
        dr = Pos2D(width, height)
        self.box = Box(ul, dr)

    def add_wall(self, pos1: Pos2D, pos2: Pos2D):
        # ajoute un mur entre pos1 et pos2 si ces positions sont adjacentes
        action = False
        Grid.change_action(self, pos1, pos2, action)

    def remove_wall(self, pos1: Pos2D, pos2: Pos2D):
        # retire un mur entre pos1 et pos2 si ces positions sont adjacentes
        action = True
        Grid.change_action(self, pos1, pos2, action)

    def isolate_box(self, box: Box):
        # ajout un rectangle dans la grid
        pos1 = box.ul
        pos2 = box.dr
        if pos1.x > 0:
            index = pos1.y
            stop = pos2.y
            while index <= stop:
                self.add_wall(Pos2D(pos1.x, index), Pos2D(pos1.x-1, index))
                index += 1
        if pos2.x < self.box.dr.x-1:
            index = pos1.y
            stop = pos2.y
            while index <= stop:
                self.add_wall(Pos2D(pos2.x, index), Pos2D(pos2.x+1, index))
                index += 1
        if pos1.y > 0:
            index = pos1.x
            stop = pos2.x
            while index <= stop:
                self.add_wall(Pos2D(index, pos1.y), Pos2D(index, pos1.y-1))
                index += 1
        if pos2.y < self.box.dr.y-1:
            index = pos1.x
            stop = pos2.x
            while index <= stop:
                self.add_wall(Pos2D(index, pos2.y), Pos2D(index, pos2.y+1))
                index += 1

    def accessible_neighbours(self, pos: Pos2D):
        # renvoie une liste contenant les cases accessibles depuis pos (return)
        listPos2D = []
        if (pos.x < self.box.dr.y and pos.y < self.box.dr.x):
            listActions = Node.getActions(self.box, pos)
            if listActions[0] == True:
                #up
                x = pos.x - 1
                listPos2D.append(Pos2D(x,pos.y))
            if listActions[1] == True:
                #left
                y = pos.y - 1
                listPos2D.append(Pos2D(pos.x,y))
            if listActions[2] == True:
                #down
                x = pos.x + 1
                listPos2D.append(Pos2D(x,pos.y))
            if listActions[3] == True:
                #right
                y = pos.y + 1
                listPos2D.append(Pos2D(pos.x,y))
        return listPos2D