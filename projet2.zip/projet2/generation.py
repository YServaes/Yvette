import argparse

import grid
from grid import Grid

class DungeonGenerator:

    def __init__(self, params: argparse.Namespace):
        parser = argparse.ArgumentParser(params)
        parser.add_argument("width", help='largeur du donjon')
        parser.add_argument("height", help='hauteur du donjon')
        parser.add_argument('--rooms', help='nombre de pieces', default=5)
        parser.add_argument('--seed', help='défini la racine pour generer le donjon', default=None)
        parser.add_argument('--minwidth', help='largeur minimum de la piece', default=4)
        parser.add_argument('--maxwidth', help='largeur maximum de la piece', default=8)
        parser.add_argument('--minheight', help='hauteur minimum de la piece', default=4)
        parser.add_argument('--maxheight', help='hauteur maximum de la piece', default=8)
        parser.add_argument('--openings', help='nombre ouverture par piece', default=2)
        parser.add_argument('--hard', help='donjon basé sur un labyrinthe')

        args = parser.parse_args()
        self.params = args

    def generate(self):
        args = self.params
        for arg in args._get_kwargs():
            print(arg)
        self.params = args

        myGrid = Grid(5,6)
        myDict = {'grid': myGrid}
        return myDict
