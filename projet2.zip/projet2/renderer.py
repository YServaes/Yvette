# affichage du donjon
from grid import *


class GridRenderer:


    def __init__(self, grid: Grid):
        sign1 = "──"
        sign2 = "┌─"
        sign3 = "┐"
        sign4 = "┬─"
        sign5 = "└─"
        sign6 = "│"
        sign7 = "├─"
        sign8 = "┘"
        sign9 = "┴"
        sign10 = "┤"
        sign11 = "┼"
        # construit un renderer d'une grille
        nbr_line = grid.box.dr.x
        nbr_col = grid.box.dr.y
        self.grid2 = []
        self.nbLine = nbr_line
        self.nbCol = nbr_col

        for x in range(nbr_line):
            #mur
            line = ''
            for y in range(nbr_col):
                actions = Node.getActions(grid.box, Pos2D(x,y))
                if actions[0] == False:
                    if x > 0:
                        actionsUp = Node.getActions(grid.box, Pos2D(x-1, y))
                        if actionsUp[1] == False:
                            if actions[1] == False:
                                line = line + sign7 + sign1
                            else:
                                line = line + sign5 + sign1
                        else:
                            if actions[1] == False:
                                line = line + sign2 + sign1
                            else:
                                line = line + sign1 + sign1
                    else:
                        if actions[1] == False:
                            if y > 0:
                                line = line + sign4 + sign1
                            else:
                                line = line + sign2 + sign1
                        else:
                            line = line + sign1 + sign1
                elif actions[1] == False:
                    line = line + sign6 + "   "
                else:
                    line = line + "  "

            if x == 0:
                line = line + sign3
            else:
                actions = Node.getActions(grid.box, Pos2D(x, nbr_col-1))
                if actions[0] == False:
                    line = line + sign10
                else:
                    line = line + "  " + sign6
            self.grid2.append(line)
            #case
            line = ''
            for y in range(nbr_col):
                actions = Node.getActions(grid.box, Pos2D(x,y))
                if actions[1] == False:
                    line = line + sign6 + "   "
                else:
                    line = line + "    "
            line = line + sign6
            self.grid2.append(line)


        line = sign5 + sign1
        for y in range(nbr_col-1):
            line = line + sign1 + sign1
        line = line + sign8
        self.grid2.append(line)


    def show(self):
        # affiche le donjon à l'écran
        print("")
        for x in range(self.nbLine*2+1):
            line = ""
            line = line + self.grid2[x]
            print(line)
