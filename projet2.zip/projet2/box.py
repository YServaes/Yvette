# définit un rectangle à partir de 2 positions => équivaut à définir les actions à chaque position de ce rectangle
from pos2d import Pos2D

class Box:


   def __init__(self, ul: Pos2D, dr: Pos2D):
        self.ul = ul
        self.dr = dr

        nbr_col = dr.x
        nbr_line = dr.y
        self.box = [[[False for col in range(4)] for col in range(nbr_col)] for row in range(nbr_line)]
        for index_line in range(nbr_line):
           up = False
           down = False
           if (index_line != 0): up = True
           if (index_line != nbr_line-1): down = True
           for index_col in range(nbr_col):
                left = False
                right = False
                if (index_col != 0): left = True
                if (index_col != nbr_col-1): right = True
                self.box[index_line][index_col] = [up,left,down,right]

   def getElement(self, x: int, y: int):
        return self.box[x][y]

